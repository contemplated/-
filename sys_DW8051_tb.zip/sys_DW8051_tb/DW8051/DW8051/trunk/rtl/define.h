//mcu rom
`define ROM_DATA_WIDTH 8
`define ROM_DATA_DEPTH 8192
`define ROM_ADDR_WIDTH 13

`define D  #1

